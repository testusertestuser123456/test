# ubuntu-box

Ubuntu 24.04 + 標準コマンド + SSH + dirsearch。
固定IP `192.168.55.10`（ネットワーク `192.168.55.0/24`、ホスト側 `192.168.55.1`）。

## 起動

```bash
docker compose up -d --build
```

## 接続

```bash
# Linuxホスト：コンテナIPに直接
ssh user@192.168.55.10

# Docker Desktop (Mac/Windows)：ポート転送経由
ssh -p 2222 user@localhost
```

## 疎通確認

```bash
ping 192.168.55.10                          # ホスト → コンテナ
docker exec ubuntu-box ping -c3 192.168.55.1  # コンテナ → ホスト
```

## dirsearch

```bash
dirsearch -u http://192.168.55.1:8080/
```

## サブネットが被る場合

`docker-compose.yml` の `192.168.55` を別の値（例 `192.168.77`）に置換。
既存の使用状況は `ip route` / `docker network inspect $(docker network ls -q) | grep Subnet` で確認できます。

## 停止・削除

```bash
docker compose down
```
