#!/bin/bash
set -e

USER_NAME="${SSH_USER:-user}"
USER_PASS="${SSH_PASSWORD:-changeme}"

# ユーザー作成（初回のみ）
if ! id "$USER_NAME" >/dev/null 2>&1; then
    useradd -m -s /bin/bash -G sudo "$USER_NAME"
fi
echo "${USER_NAME}:${USER_PASS}" | chpasswd

# 公開鍵があれば登録
if [ -n "$SSH_PUBKEY" ]; then
    install -d -m 700 -o "$USER_NAME" -g "$USER_NAME" "/home/$USER_NAME/.ssh"
    echo "$SSH_PUBKEY" > "/home/$USER_NAME/.ssh/authorized_keys"
    chown "$USER_NAME:$USER_NAME" "/home/$USER_NAME/.ssh/authorized_keys"
    chmod 600 "/home/$USER_NAME/.ssh/authorized_keys"
fi

# ホスト鍵生成（無ければ）
ssh-keygen -A

echo "SSH ready: ${USER_NAME}@$(hostname -I | awk '{print $1}')"
exec /usr/sbin/sshd -D -e
