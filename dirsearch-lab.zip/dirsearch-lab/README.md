# dirsearch 検証ラボ

| コンテナ | IP | 役割 |
|---|---|---|
| dslab-victim | 192.168.35.10 | nginx（4階層のディレクトリ） |
| dslab-proxy | 192.168.35.20:8888 | tinyproxy（HTTPプロキシ、Basic認証 user / password） |
| dslab-attacker | 192.168.35.30 | dirsearch + proxychains4 |

- ホストへのポート公開なし。ネットワークは `dslab_net`（192.168.35.0/24）
- 判定はビクティムのログで行う：送信元IPが `.30` なら直通、`.20` ならプロキシ経由

## 使い方
```bash
docker compose up -d --build
./run_tests.sh            # 自動テスト（PASS/FAIL表示）
docker exec -it dslab-attacker bash   # 手動で試す（エイリアスが使える）
docker compose down       # 片付け
```

## プロキシ経由の例（attacker内）
```bash
# --proxy オプション（認証情報はURLに埋め込む）
dirsearch -u http://192.168.35.10/ -w /lab/wordlist.txt --proxy http://user:password@192.168.35.20:8888

# proxychains（認証情報は /etc/proxychains4.conf に記載済み）
#   [ProxyList]
#   http 192.168.35.20 8888 user password
proxychains4 -q dirsearch -u http://192.168.35.10/ -w /lab/wordlist.txt
```
認証なしで `--proxy http://192.168.35.20:8888` を指定すると 407 で弾かれる（T2N で確認）。

## ビクティムの階層
```
/admin/                       1
/admin/backup/                2
/admin/backup/old/secret.txt  3
/admin/backup/old/deep/flag.txt 4
```

## エイリアス（attacker内）
- `dsua -u $T` UA入り / `dsproxy -u $T` UA+--proxy / `dspc -u $T` proxychains+UA / `dsrec -u $T` 再帰
- ログ確認: 別ターミナルで `docker logs -f dslab-victim`
