
# ===== dslab aliases =====
export T=http://192.168.35.10/
export PX=http://user:password@192.168.35.20:8888
export WL=/lab/wordlist.txt

# UA をエイリアスに埋め込み（直通）
alias dsua='dirsearch -w $WL -t 5 --user-agent "DSLAB-ALIAS-UA"'
# UA + --proxy をエイリアスに埋め込み
alias dsproxy='dirsearch -w $WL -t 5 --user-agent "DSLAB-ALIAS-PROXY" --proxy $PX'
# proxychains + UA をエイリアスに埋め込み
alias dspc='proxychains4 -q dirsearch -w $WL -t 5 --user-agent "DSLAB-ALIAS-PC"'
# 再帰付き
alias dsrec='dirsearch -w $WL -t 5 -r --user-agent "DSLAB-ALIAS-REC"'
