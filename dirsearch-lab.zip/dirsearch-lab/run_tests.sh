#!/usr/bin/env bash
# ホスト側で実行: ./run_tests.sh
# ビクティムのアクセスログ（送信元IP / UA / Via）で各テストを判定する
set -u
A=dslab-attacker
V=dslab-victim
T=http://192.168.35.10/
PX=http://user:password@192.168.35.20:8888
PX_NOAUTH=http://192.168.35.20:8888
WL=/lab/wordlist.txt
DIRECT_IP=192.168.35.30
PROXY_IP=192.168.35.20
PASS=0; FAIL=0

run() {  # run <name> <command...>  (attacker内で実行、出力は /lab/out/<name>.txt)
  local name=$1; shift
  echo "[*] $name 実行中..."
  docker exec "$A" bash -c "mkdir -p /lab/out; $* > /lab/out/$name.txt 2>&1"
}
run_alias() {  # エイリアスは対話シェルでのみ展開されるので bash -ic
  local name=$1; shift
  echo "[*] $name 実行中 (alias)..."
  docker exec "$A" bash -ic "mkdir -p /lab/out; $* > /lab/out/$name.txt 2>&1" 2>/dev/null
}
logs() { docker exec "$V" grep -F "ua=\"$1\"" /var/log/nginx/lab.log; }
result() { if [ "$1" = ok ]; then echo "  [PASS] $2"; PASS=$((PASS+1)); else echo "  [FAIL] $2"; FAIL=$((FAIL+1)); fi; }

check_ip() {  # check_ip <UA> <期待IP> <説明>
  local l n bad
  l=$(logs "$1"); n=$(printf '%s' "$l" | grep -c . )
  bad=$(printf '%s\n' "$l" | awk -F' [|] ' -v ip="$2" 'NF && $1!=ip' | wc -l)
  if [ "$n" -gt 0 ] && [ "$bad" -eq 0 ]; then result ok "$3 (UA=$1, $n req, 全て from $2)"
  else result ng "$3 (UA=$1, $n req, 期待IP以外=$bad)"; fi
}
check_has() {  # check_has <UA> <パス> <説明>
  if logs "$1" | grep -q "| 200 | GET $2 "; then result ok "$3"; else result ng "$3"; fi
}
check_none() {  # 1件も届いていないこと
  local n; n=$(logs "$1" | grep -c .)
  if [ "$n" -eq 0 ]; then result ok "$2"; else result ng "$2 ($n req 到達)"; fi
}
check_not() {
  if logs "$1" | grep -q "GET $2 "; then result ng "$3"; else result ok "$3"; fi
}

docker exec "$V" sh -c ': > /var/log/nginx/lab.log'

run T1 dirsearch -u $T -w $WL -t 5 --user-agent T1-DIRECT
run T2 dirsearch -u $T -w $WL -t 5 --user-agent T2-PROXYOPT --proxy $PX
run T2N dirsearch -u $T -w $WL -t 5 --user-agent T2N-NOAUTH --proxy $PX_NOAUTH
run T3 proxychains4 -q dirsearch -u $T -w $WL -t 5 --user-agent T3-PROXYCHAINS
run_alias T4 'dsua -u $T'
run_alias T5 'dsproxy -u $T'
run_alias T6 'dspc -u $T'
run T7 dirsearch -u $T -w $WL -t 5 -r --user-agent T7-RECURSIVE
run T8 dirsearch -u $T -w $WL -t 5 -r -R 1 --user-agent T8-DEPTH1
run_alias T9 'dsrec -u $T'

echo; echo "===== 判定 ====="
echo "-- 直通 / プロキシ --"
check_ip T1-DIRECT       $DIRECT_IP "T1 直通"
check_ip T2-PROXYOPT     $PROXY_IP  "T2 --proxy オプション"
check_none T2N-NOAUTH                "T2N 認証なし --proxy → 407で弾かれ、ビクティムに届かない"
check_ip T3-PROXYCHAINS  $PROXY_IP  "T3 proxychains4"
echo "-- User-Agent をエイリアスに入れた場合 --"
check_ip DSLAB-ALIAS-UA    $DIRECT_IP "T4 alias(UA)"
check_ip DSLAB-ALIAS-PROXY $PROXY_IP  "T5 alias(UA + --proxy)"
check_ip DSLAB-ALIAS-PC    $PROXY_IP  "T6 alias(proxychains + UA)"
echo "-- 再帰 --"
check_not T1-DIRECT      /admin/backup/                      "T1 再帰なし → /admin/backup/ を叩かない"
check_has T7-RECURSIVE   /admin/backup/old/secret.txt        "T7 -r → 3階層目 secret.txt 発見"
check_has T7-RECURSIVE   /admin/backup/old/deep/flag.txt     "T7 -r → 4階層目 deep/flag.txt 発見"
check_not T8-DEPTH1      /admin/backup/old/secret.txt        "T8 -r -R 1 → 深さ制限で secret.txt まで行かない"
check_has DSLAB-ALIAS-REC /admin/backup/old/secret.txt       "T9 alias(-r) → secret.txt 発見"

echo; echo "PASS=$PASS FAIL=$FAIL"
echo "詳細: docker exec $V cat /var/log/nginx/lab.log"
echo "      docker exec $A cat /lab/out/T1.txt   (T1〜T9)"
echo "      docker logs dslab-proxy"
